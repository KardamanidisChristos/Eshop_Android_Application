package com.example.eshopproject;

import android.util.Log;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RestClient {

  final String apiAuthorization = "1234567890";

  OkHttpClient client;
  public RestClient() {
    client = new OkHttpClient();
  }

  public JSONObject doPost(String url, JSONObject body) throws JSONException, IOException {
    MediaType JSON = MediaType.parse("application/json;charset=utf-8");

    RequestBody requestBody = RequestBody.create(JSON,body.toString());
    Request request = new Request.Builder().url(url).post(requestBody).build();

    Response response = client.newCall(request).execute();
    String data = response.body().string();
    JSONObject jsonObject = new JSONObject(data);
    return  jsonObject;
  }

  public String doGetRequest(String url) throws JSONException,IOException{
    Request newRewuest = new  Request.Builder().url(url).addHeader("Authorization",apiAuthorization).build();
    Log.d("Request build status:","Request built");
    Response response = client.newCall(newRewuest).execute();
    Log.d("Execution status:","Request executed");
    String data = response.body().string();
    Log.d("Message extracted",data);
    return data;
  }

}
