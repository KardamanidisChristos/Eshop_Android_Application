package com.example.eshopproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

public class AdministratorManagement extends AppCompatActivity {
    TextView textView;
    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administrator_management);
        /*
        handler = new Handler(getApplicationContext().getMainLooper());
        //final String data = null;
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                //final String data = getCategories();
                final String data = addexampleCategory().toString();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("MESSAGE", "re broooooooooooooooooooo");
                        //fillTv(data);
                        textView = findViewById(R.id.categoriestv);
                        textView.setText(data);


                    }
                });



            }


        });
        thread.start();

*/





    }
    private void fillTv(String tv) {
        textView = findViewById(R.id.categoriestv);
        //textView.setText(tv);
        addexampleCategory();
        textView.setText("OK");

    }
    private String getCategories(){
        RestClient rc = new RestClient();
        try {
            return rc.doGetRequest("http://192.168.1.70/ptyxiaki/index.php/api/v1/Products");
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;

    }
    private JSONObject addCategory(JSONObject requestbody) throws IOException, JSONException {
        RestClient restClient = new RestClient();
        return restClient.doPost("http://192.168.1.70/ptyxiaki/index.php/api/v1/Categories", requestbody);
    }

    private JSONObject addexampleCategory() {
        JSONObject object = new JSONObject();
        try {
            object.put("categoryname","autokolita");
            JSONObject jsonObject = addCategory(object);
            return jsonObject;
        } catch (JSONException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
