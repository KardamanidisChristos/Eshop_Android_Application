package com.example.eshopproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WarehousemanManagement extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warehouseman_management);
    }
}
